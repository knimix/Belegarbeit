glslc -fshader-stage=vert vertex.glsl -o vertex.spv
glslc -fshader-stage=frag fragment.glsl -o fragment.spv
